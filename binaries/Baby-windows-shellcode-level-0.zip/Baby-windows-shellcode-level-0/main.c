#include <windows.h>
#include <stdio.h>

void setup(void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
}

void print_info(void) {
	puts("Baby Windows buffer overflow by Cl1nical");
	puts("Level: 0");
	puts("Theme: Shellcode injection");
	puts("");
	puts("DEP:                  Disabled");
	puts("Canary:               Disabled");
	puts("ASLR:                 Disabled");
	puts("PIE:                  Disabled");
	puts("CFG:                  Disabled");
	puts("CET (Shadow Stack):   Disabled");
	puts("");
}

void vuln(void)
{
	char buffer[0x100];
	DWORD lpflOldProtect;

	if (VirtualProtect(buffer, 0x100, PAGE_EXECUTE_READWRITE, &lpflOldProtect) == 0) {
		perror("Buffer could not be set RWX");
	}

	printf("Input > ");
	fgets(buffer, 0x300, stdin);
}

int main(void)
{
	setup();

	print_info();

	vuln();

	return 0;
}