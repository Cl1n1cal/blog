#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>

char *chunks[16] = {0};
uint32_t sizes[16] = {};

void error(const char *reason)
{
    printf("Error: %30s\n", reason);
    exit(1);
}

void setup()
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

uint32_t get_index()
{
    uint32_t index;
    scanf("%u", &index);
    return index;
}

void check_index_range(uint32_t index)\
{
    if (index < 0 || 15 < index) {
        error("Index out of range 0-15");
    }
}

void print_menu()
{
    puts("MENU:");
    puts("1: Malloc");
    puts("2: Free");
    puts("3: Edit");
    puts("4: Print");
    printf("> ");
}

void alloc_mem()
{
    uint32_t size;
    uint32_t index;

    puts("Index:");
    printf("> ");
    scanf("%u", &index);

    check_index_range(index);

    puts("Size:");
    printf("> ");
    scanf("%u", &size);

    if (size > 0x3000) {
        puts("Size too large");
        exit(1);
    }

    chunks[index] = malloc(size);

    if (chunks[index] == NULL) {
        error("Allocation failed");
    }

    puts("Input:");
    printf("> ");
    read(0, chunks[index], size-1);
    sizes[index] = size;
}

void free_mem()
{
    uint32_t index;

    puts("Index:");
    printf("> ");

    scanf("%u", &index);
    
    check_index_range(index);

    if (chunks[index] == NULL || sizes[index] == 0) {
        puts("Cannot free NULL index");
        return;
    }

    free(chunks[index]);
}

void edit_mem()
{
    uint32_t index;
    uint32_t size;

    puts("Index:");
    printf("> ");

    index = get_index();

    check_index_range(index);


    if (chunks[index] == NULL || sizes[index] == 0) {
        puts("Index was NULL");
        return;
    } 

    size = sizes[index];

    puts("Input:");
    printf("> ");
    read(0, chunks[index], size-1);
}

void print_mem()
{
    uint32_t index;

    puts("Index:");
    printf("> ");
    
    index = get_index();

    check_index_range(index);

    puts("Data:");
    printf("> ");
    puts(chunks[index]);
    return;
}

int main(void)
{
    setup();

    puts("This challenge supports up to 16 allocations");
    char buf[3];
    char choice;
    while(1) {
        print_menu();
        read(0, buf, 2);
        choice = buf[0];

        switch (choice)
        {
        case '1':
            alloc_mem();
            break;
        case '2':
            free_mem();
            break;
        case '3':
            edit_mem();
            break;
        case '4':
            print_mem();
            break;
        
        default:
            error("Invalid choice");
            break;
        }
    }

    return 0;
}